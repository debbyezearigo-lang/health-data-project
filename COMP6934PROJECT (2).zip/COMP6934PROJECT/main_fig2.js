(function() {

    d3.csv("final_health_dataset_project.csv").then(function(data) {

        data.forEach(d => {
            d.year = +d.year;
            d.life_expect = +d.life_expect;
            d.GDP_per_capita = +d.GDP_per_capita;

            if (isNaN(d.life_expect)) d.life_expect = null;
            if (isNaN(d.GDP_per_capita)) d.GDP_per_capita = null;
        });


      

        const merged = d3.groups(data, d => d.country)
            .map(([country, values]) => {
                const v1999 = values.find(d => d.year === 1999);
                const v2022 = values.find(d => d.year === 2022);

                if (!v1999 || !v2022) return null;

                return {
                    country: country,
                    life: v2022.life_expect,
                    GDP_per_capita: v2022.GDP_per_capita,
                    change: v2022.life_expect - v1999.life_expect
                };
            })
            .filter(d => 
                d !== null && 
                d.life != null && 
                !isNaN(d.life) &&
                d.GDP_per_capita > 0 &&
                !isNaN(d.GDP_per_capita) &&
                !isNaN(d.change));

        

        const yMin = d3.min(merged, d => d.life);
        const yMax = d3.max(merged, d => d.life);

        const countries = Array.from(new Set(data.map(d => d.country))).sort();

        const dropdown = d3.select("#country-select");

        dropdown.selectAll("option.country-option")
            .data(countries)
            .enter()
            .append("option")
            .attr("class", "country-option")
            .attr("value", d => d)
            .text(d => d);

        const scatterWidth = 800;
        const scatterHeight = 400;

        const scatterSvg = d3.select("#scatter-chart")
            .append("svg")
            .attr("width", scatterWidth)
            .attr("height", scatterHeight);

        const margin = { top: 70, right: 40, bottom: 60, left: 120 };
        const innerWidth = scatterWidth - margin.left - margin.right;
        const innerHeight = scatterHeight - margin.top - margin.bottom;

        const gScatter = scatterSvg.append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);

        const legend = scatterSvg.append("g")
            .attr("transform", `translate(10, ${margin.top})`);

        legend.append("circle")
            .attr("cx", 0)
            .attr("cy", 0)
            .attr("r", 5)
            .attr("fill", "green");

        legend.append("text")
            .attr("x", 10)
            .attr("y", 4)
            .text("Increase")
            .style("font-size", "12px");

        legend.append("circle")
            .attr("cx", 0)
            .attr("cy", 20)
            .attr("r", 5)
            .attr("fill", "red");

        legend.append("text")
            .attr("x", 10)
            .attr("y", 24)
            .text("Decrease")
            .style("font-size", "12px");

        legend.append("circle")
            .attr("cx", 0)
            .attr("cy", 40)
            .attr("r", 5)
            .attr("fill", "gray");

        legend.append("text")
            .attr("x", 10)
            .attr("y", 44)
            .text("No Change")
            .style("font-size", "12px");

        const xScatter = d3.scaleLinear()
            .domain(d3.extent(merged, d => d.GDP_per_capita))
            .range([0, innerWidth]);

        const yPadding = 2;

        const yScatter = d3.scaleLinear()
            .domain([yMin - yPadding, yMax + yPadding])
            .nice()
            .range([innerHeight, 0]);

        gScatter.append("g")
            .attr("transform", `translate(0,${innerHeight})`)
            .call(d3.axisBottom(xScatter)
            .ticks(5)
            .tickFormat(d3.format(".2s")));

        gScatter.append("g")
            .call(d3.axisLeft(yScatter));

        gScatter.append("text")
            .attr("x", innerWidth / 2)
            .attr("y", -10)
            .attr("text-anchor", "middle")
            .style("font-size", "14px")
            .text("Relationship Between GDP per Capita and Life Expectancy (2022)");

        gScatter.append("text")
            .attr("x", innerWidth / 2)
            .attr("y", 10)
            .attr("text-anchor", "middle")
            .style("font-size", "12px")
            .style("fill", "#555")
            .text("Click a country/point to view its trend over time")

        gScatter.append("text")
            .attr("x", innerWidth / 2)
            .attr("y", innerHeight + 35)
            .attr("text-anchor", "middle")
            .text("GDP per Capita (USD)");

        gScatter.append("text")
            .attr("transform", "rotate(-90)")
            .attr("x", -innerHeight / 2)
            .attr("y", -60)
            .attr("text-anchor", "middle")
            .text("Life Expectancy (years)");

        gScatter.append("line")
            .attr("x1", 0)
            .attr("x2", innerWidth)
            .attr("y1", innerHeight)
            .attr("y2", 0)
            .attr("stroke", "black")
            .attr("stroke-dasharray", "4");

        gScatter.selectAll("path, line")
            .attr("stroke", "black");

        gScatter.append("g")
            .attr("class", "grid")
            .call(
                d3.axisLeft(yScatter)
                    .tickSize(-innerWidth)
                    .tickFormat("")
            )
            .selectAll("line")
            .attr("stroke", "#ddd")
            .attr("stroke-opacity", 0.7);

        gScatter.append("g")
            .attr("class", "grid")
            .attr("transform", `translate(0,${innerHeight})`)
            .call(
                d3.axisBottom(xScatter)
                    .tickSize(-innerHeight)
                    .tickFormat("")
            )
            .selectAll("line")
            .attr("stroke", "#ddd")
            .attr("stroke-opacity", 0.7);

        function resetSelectionSmooth() {
            selectedCountry = null;

            lineGroup.selectAll(".animated-line")
                .transition()
                .duration(300)
                .style("opacity", 0)
                .remove();

            lineGroup.selectAll(".line-point")
                .transition()
                .duration(300)
                .style("opacity", 0)
                .remove();

            points.transition()
                .duration(400)
                .attr("opacity", 0.6)
                .attr("r", 4)
                .attr("stroke", "none")
                .attr("stroke-width", 0);
        }

        gScatter.on("click", function(event) {
            if(event.target.tagName === "circle") return;

            resetSelectionSmooth();

            dropdown.property("value", "all");
        });

        


        const colorScale = d => d.change < 0 ? "red" : "green";

        const points = gScatter.selectAll("circle")
            .data(merged)
            .enter()
            .append("circle")
            .attr("cx", d => xScatter(d.GDP_per_capita))
            .attr("cy", d => yScatter(d.life))
            .attr("r", 4)
            .attr("fill", d => {
                if (d.change < 0) return "red";
                if (d.change > 0) return "green";
                return "gray";
            })
            .attr("opacity", 0.6)
            .attr("stroke", "none")
            .style("cursor", "pointer");

        const tooltip = d3.select("body")
            .append("div")
            .style("position", "absolute")
            .style("background", "white")
            .style("border", "1px solid #ccc")
            .style("padding", "6px")
            .style("font-size", "12px")
            .style("border-radius", "4px")
            .style("pointer-events", "none")
            .style("opacity", 0);
        

       

        const lineWidth = 800;
        const lineHeigth = 400;

        const lineSvg = d3.select("#line-chart")
            .append("svg")
            .attr("width", lineWidth)
            .attr("height", lineHeigth);

        const gLine = lineSvg.append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);

        const innerWidthline = lineWidth - margin.left - margin.right;
        const innerHeightline = lineHeigth - margin.top - margin.bottom;

        const xLine = d3.scaleLinear()
            .domain(d3.extent(data.filter(d => d.year && !isNaN(d.year)), d => d.year))
            .range([0, innerWidthline]);

        const yLine = d3.scaleLinear()
            .domain(d3.extent(data.filter(d => d.life_expect != null), d => d.life_expect))
            .nice()
            .range([innerHeightline, 0]);

        gLine.append("g")
            .attr("transform", `translate(0,${innerHeightline})`)
            .call(d3.axisBottom(xLine).tickFormat(d3.format("d")));

        gLine.append("g")
            .call(d3.axisLeft(yLine));

        

        gLine.append("text")
            .attr("x", innerWidthline / 2)
            .attr("y", innerHeightline + 35)
            .attr("text-anchor", "middle")
            .text("Year");

        gLine.append("text")
            .attr("transform", "rotate(-90)")
            .attr("x", -innerHeightline / 2)
            .attr("y", -55)
            .attr("text-anchor", "middle")
            .text("Life Expectancy");

        gLine.selectAll("path, line")
            .attr("stroke", "black");

        gLine.append("g")
            .attr("class", "grid")
            .call(
                d3.axisLeft(yLine)
                    .tickSize(-innerWidthline)
                    .tickFormat("")
            )
            .selectAll("line")
            .attr("stroke", "#ddd")
            .attr("stroke-opacity", 0.7);

        gLine.append("g")
            .attr("class", "grid")
            .attr("transform", `translate(0,${innerHeightline})`)
            .call(
                d3.axisBottom(xLine)
                    .tickSize(-innerHeightline)
                    .tickFormat("")
            )
            .selectAll("line")
            .attr("stroke", "#ddd")
            .attr("stroke-opacity", 0.7);

        const grouped = d3.groups(data, d => d.country);

        const line = d3.line()
            .x(d => xLine(d.year))
            .y(d => yLine(d.life_expect));

        const lineGroup = gLine.append("g");

    
        function drawAnimatedLine(countryName) {

            lineGroup.selectAll(".animated-line").remove();
            lineGroup.selectAll(".line-point").remove();

            const countryData = grouped.find(d => d[0] === countryName);

            if (!countryData) return;

            const values = countryData[1]
                .filter(d => d.life_expect != null && !isNaN(d.life_expect))
                .sort((a, b) => a.year - b.year);

            

            const path = lineGroup.append("path")
                .datum(values)
                .attr("class", "animated-line")
                .attr("fill", "none")
                .attr("stroke", "steelblue")
                .attr("stroke-width", 3)
                .attr("d", line);

            const totalLength = path.node().getTotalLength();

            path
                .attr("stroke-dasharray", totalLength)
                .attr("stroke-dashoffset", totalLength)
                .transition()
                .duration(1200)
                .ease(d3.easeLinear)
                .attr("stroke-dashoffset", 0);

            lineGroup.selectAll(".line-point")
                .data(values, d => d.year)
                .enter()
                .append("circle")
                .attr("class", "line-point")
                .attr("cx", d => xLine(d.year))
                .attr("cy", d => yLine(d.life_expect))
                .attr("r", 4)
                .attr("fill", "black")
                .on("mouseover", function(event, d) {
                    tooltip.style("opacity", 1)
                        .html(`
                            <strong>${countryName}</strong><br/>
                            Year: ${d.year}<br/>
                            Life Expectancy: ${d.life_expect.toFixed(1)}
                        `);
                })
                .on("mousemove", function(event) {
                    tooltip.style("left", (event.pageX + 10) + "px")
                            .style("top", (event.pageY + 10) + "px");
                })
                .on("mouseout", function() {
                    tooltip.style("opacity", 0);
                });

            

            dynamicTitle
                .transition()
                .duration(300)
                .style("opacity", 0)
                .on("end", function() {
                    d3.select(this)
                        .text(`Life Expectancy Trend Over Time: ${countryName}`)
                        .transition()
                        .duration(300)
                        .style("opacity", 1);
                });

            const v1999 = values.find(d => d.year === 1999);
            const v2022 = values.find(d => d.year === 2022);

            if (!v1999 || !v2022) return;

            const changeValue = v2022.life_expect - v1999.life_expect;

            changeText
                .transition()
                .duration(300)
                .style("opacity", 0)
                .on("end", function () {
                    d3.select(this)
                        .text(`Change in Life Expectancy: ${changeValue> 0 ? "+" : ""}${changeValue.toFixed(1)} years`)
                        .style("fill", changeValue > 0 ? "green" : "red")
                        .style("font-weight", "bold")
                        .transition()
                        .duration(500)
                        .style("opacity", 1);
            });
        }
 

        const dynamicTitle = lineSvg.append("text")
                .attr("x", lineWidth / 2)
                .attr("y", 25)
                .attr("text-anchor", "middle")
                .style("font-size", "14px")
                .style("fill", "#333")
                .style("font-weight", "bold")
                .text("Life Expectancy Trends Over Time");

        const changeText = lineSvg.append("text")
            .attr("x", lineWidth - 20)
            .attr("y", 50)
            .attr("text-anchor", "end")
            .style("font-size", "13px")
            .style("fill", "#444")
            .style("opacity", 0);

 
        let selectedCountry = null;

        function updateCharts(country) {
            selectedCountry = country;

            if (country === "all") {
                lineGroup.selectAll("*").remove();
                points.attr("opacity", 0.6).attr("r", 4);
                return;
            }

            drawAnimatedLine(country);

            points
                .transition()
                .duration(300)
                .attr("opacity", d => d.country === country ? 1 : 0.2)
                .attr("r", d => d.country === country ? 9 : 4)
                .attr("stroke", d => d.country === country ? "black" : "none")
                .attr("stroke-width", 1.5);
/*
            selectedCountry = (country === "all") ? null : country;


            points
                .transition()
                .duration(300)
                .attr("opacity", d => {
                    if (!selectedCountry) return 0.7;
                    return d.country === selectedCountry ? 1 : 0.2;
                })
                .attr("r", d => d.country === selectedCountry ? 9 : 4)
                .attr("stroke", d => d.country === selectedCountry ? "black" : "none")
                .attr("stroke-width", d => d.country === selectedCountry ? 1.5 : 0);
*/
            points
                .on("mouseover", function(event, d) {
                    tooltip.style("opacity", 1)
                        .html(`
                            <strong>${d.country}</strong><br/>
                            GDP per Capita: ${d.GDP_per_capita.toFixed(2)}<br/>
                            Life Expectancy: ${d.life.toFixed(1)}<br/>
                            Change: ${d.change.toFixed(2)}    
                        `);
                })
                .on("mousemove", function(event) {
                    tooltip.style("left", (event.pageX + 10) + "px")
                            .style("top", (event.pageY + 10) + "px");
                })
                .on("mouseout", function() {
                    tooltip.style("opacity", 0);
                });
           

        } 

        points.on("click", function(event, d) {
            event.stopPropagation();

            if (selectedCountry === d.country) {
                resetSelectionSmooth();
                dropdown.property("value", "all");
            } else {
                selectedCountry = d.country;
                updateCharts(d.country);
                dropdown.property("value", d.country);
            }

        });

        dropdown.on("change", function() {
            const selected = d3.select(this).property("value");
            updateCharts(selected);
        });

        

        

    });
})();