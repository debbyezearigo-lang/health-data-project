console.log("MAIN JS LOADED - UPDATED VERSION");
d3.csv("final_health_dataset_project.csv").then(function(data) {

    

    const width = 800;
    const height = 400;
    const margin = { top: 50, right: 30, bottom: 50, left: 60 };

    const incomeOrder = [
        "High income",
        "Upper middle income",
        "Lower middle income",
        "Low income"
    ];

    const color = d3.scaleOrdinal()
        .domain(incomeOrder)
        .range(["#4e79a7", "#f28e2b", "#e15759", "#76b7b2"]);


    data.forEach(d => {
        d.life_expect = +d.life_expect;
        d.infant_mortality = +d.infant_mortality;
        d.year = +d.year;
    });

    const filteredData = data
        .filter(d => d["Income group"]);

    console.log(filteredData);

    const regions = Array.from(new Set(filteredData.map(d => d.Region).filter(d => d)));
    const years = Array.from(new Set(filteredData.map(d => d.year))).sort();

    let currentRegion = regions[0];
    let currentYearIndex = 0;
    let currentYear = years[0];
    let isPlaying = false;

    const buttonContainer = d3.select("#region-buttons");

    buttonContainer.append("h3").text("Selected Region");

    buttonContainer.selectAll("button")
        .data(regions)
        .enter()
        .append("button")
        .text(d => d)
        .style("display", "block")
        .style("margin", "5px 0")
        .on("click", function(event, selectedRegion) {
            currentRegion = selectedRegion;
            currentYearIndex = 0;
            currentYear = years[currentYearIndex];
            yearSelect.property("value", currentYear);
            updateCharts(currentRegion, currentYear);
        });

    const yearContainer = d3.select("#region-buttons")
        .append("div")
        .style("margin-top", "15px")

    yearContainer.append("h3").text("Select Year");

    const yearSelect = yearContainer.append("select");

    yearSelect.selectAll("option")
        .data(years)
        .enter()
        .append("option")
        .attr("value", d => d)
        .text(d => d);

    yearSelect.on("change", function() {
            currentYear = +this.value;
            currentYearIndex = years.indexOf(currentYear);
            updateCharts(currentRegion, currentYear);
    });
        

    buttonContainer.append("button")
        .text("Play / Pause")
        .style("margin-top", "10px")
        .on("click", function() {
            isPlaying = !isPlaying;
            if (isPlaying) {
                playAnimation();
            }
        });

    const tooltip = d3.select("body")
        .append("div")
        .style("position", "absolute")
        .style("background", "#fff")
        .style("border", "1px solid #ccc")
        .style("padding", "8px")
        .style("border-radius", "5px")
        .style("pointer-events", "none")
        .style("opacity", 0);

    

    function clearGapChart() {
        svg3.selectAll(".gap-line-path").remove();
        svg3.selectAll(".gap-dot").remove();
        svg3.selectAll(".year-line").remove();
        svg3.selectAll(".trend-annotation").remove();
        svg3.selectAll(".no-gap-data").remove();
    }


    function playAnimation() {
        if (!isPlaying) return;

        const year = years[currentYearIndex];
        currentYear = year;

        yearSelect.property("value", year);

        updateCharts(currentRegion, year);

        currentYearIndex = (currentYearIndex + 1) % years.length;

        setTimeout(playAnimation, 1000);
    }

    const svg1 = d3.select("#vis1")
        .append("svg")
        .attr("width", width)
        .attr("height", height);

    const svg2 = d3.select("#vis2")
        .append("svg")
        .attr("width", width)
        .attr("height", height);

    const g1 = svg1.append("g");
    const g2 = svg2.append("g");

    const x1 = d3.scaleBand()
        .domain(incomeOrder)
        .range([margin.left, width - margin.right])
        .padding(0.2);
    
    const x2 = d3.scaleBand()
        .domain(incomeOrder)
        .range([margin.left, width - margin.right])
        .padding(0.2);

    const y1 = d3.scaleLinear()
        .range([height - margin.bottom, margin.top]);

    const y2 = d3.scaleLinear()
        .range([height - margin.bottom, margin.top]);

    const xAxis1 = svg1.append("g")
        .attr("transform", `translate(0,${height - margin.bottom})`);

    const yAxis1 = svg1.append("g")
        .attr("transform", `translate(${margin.left},0)`);

    const xAxis2 = svg2.append("g")
        .attr("transform", `translate(0,${height - margin.bottom})`);

    const yAxis2 = svg2.append("g")
        .attr("transform", `translate(${margin.left},0)`);

    svg1.append("text")
        .attr("x", width / 2)
        .attr("y", height - 5)
        .attr("text-anchor", "middle")
        .text("Income Group");

    svg1.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -height / 2)
        .attr("y", 15)
        .attr("text-anchor", "middle")
        .text("Life Expectancy");

    
    svg2.append("text")
        .attr("x", width / 2)
        .attr("y", height - 5)
        .attr("text-anchor", "middle")
        .text("Income Group");

    svg2.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -height / 2)
        .attr("y", 15)
        .attr("text-anchor", "middle")
        .text("Infant Mortality");

    const svg3 = d3.select("#vis3")
        .append("svg")
        .attr("width", width)
        .attr("height", height);

    const x3 = d3.scaleLinear()
        .range([margin.left, width - margin.right]);

    const y3 = d3.scaleLinear()
        .range([height - margin.bottom, margin.top]);

    const xAxis3 = svg3.append("g")
        .attr("transform", `translate(0,${height - margin.bottom})`);

    const yAxis3 = svg3.append("g")
        .attr("transform", `translate(${margin.left},0)`);

    svg3.append("text")
        .attr("x", width / 2)
        .attr("y", height - 5)
        .attr("text-anchor", "middle")
        .text("Year");

    svg3.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -height / 2)
        .attr("y", 15)
        .attr("text-anchor", "middle")
        .text("Life Expectancy Gap (Low - High");

    svg3.append("text")
        .attr("class", "title")
        .attr("x", width / 2)
        .attr("y", margin.top - 20)
        .attr("text-anchor", "middle")
        .style("font-size", "16px")
        .style("font-weight", "bold")
        .text("Income Inequality Over Time");

    const gapInsightText = svg3.append("text")
        .attr("class", "gap-insight-text")
        .attr("x", width / 2)
        .attr("y", margin.top + 10)
        .attr("text-anchor", "middle")
        .style("font-size", "14px")
        .style("font-weight", "bold");

    const gapLine = d3.line()
        .x(d => x3(d.year))
        .y(d => y3(d.gap))
        .defined(d => d.gap !== null);

    function completeData(aggregated, valuekey) {
        const map = new Map(aggregated.map(d => [d.income?.trim(), d.value]));
        return incomeOrder.map(income => ({
            income,
            value: map.get(income) ?? 0,
            missing: !map.has(income)
        }));
    }

    

    function updateCharts(selectedRegion, selectedYear) {

        selectedYear = +selectedYear;

        const regionFiltered = filteredData
            .filter(d => d.Region === selectedRegion)
            .filter(d => d.year === selectedYear);

        const lifeAgg = d3.rollups(
            regionFiltered.filter(d => 
                d.life_expect !== null &&
                !isNaN(d.life_expect) &&
                d.life_expect > 0
            ),
            v => d3.mean(v, d => d.life_expect),
            d => d["Income group"]?.trim()
        ).map(d => ({
            income: d[0],
            value: d[1]
        }));

        const mortalityData = d3.rollups(
            regionFiltered.filter(d => 
                d.infant_mortality !== null &&
                !isNaN(d.infant_mortality) &&
                d.infant_mortality > 0 &&
                d["Income group"]
            ),
            v => d3.mean(v, d => d.infant_mortality),
            d => (d["Income group"] || "").trim()
        );

        const mortalityAgg = mortalityData.map(d => ({
            income: d[0],
            value: d[1]
        }));

        const lifeData = completeData(lifeAgg);
        const mortalityFormatted = completeData(mortalityAgg);

        console.log(mortalityFormatted.map(d => d.income));
        console.log(incomeOrder);
        console.log(d3.max(mortalityFormatted, d => d.value));
        console.log("Region:", selectedRegion, "Year:", selectedYear);
        console.log("Filtered rows:", regionFiltered.length);
        console.log("Life values sample:", regionFiltered.map(d => d.life_expect));
        console.log(
            "Available income groups:",
            [...new Set(regionFiltered.map(d => d["Income group"]))]
        );
        console.log("Region:", selectedRegion);
        

        const gapData = years.map(year => {

            const yearData = filteredData.filter(d =>
                d.Region === selectedRegion && d.year === year
            );

            const grouped = d3.group(yearData, d => (d["Income group"] || "").trim());

            const highGroup = grouped.get("High income") || [];
            const lowGroup = grouped.get("Low income") || [];

            const high = d3.mean(highGroup, d => d.life_expect);
            const low = d3.mean(lowGroup, d => d.life_expect);

            return {
                year,
                gap: (high != null && low != null) ? (low - high) : null
            };
        }).filter(d => d.gap != null);

        const currentGapPoint = gapData.find(d => d.year === selectedYear);

        if (currentGapPoint) {
            const gapValue = currentGapPoint.gap;

            const absGap = Math.abs(gapValue);

            let interpretation = absGap > 10
                ? "High inequality"
                : "Lower inequality";

            let direction = gapValue < 0
                ? "Low-income groups have lower life expectancy"
                : "High-income groups have lower life expectancy";

           
            gapInsightText.text(
                `Gap: ${gapValue.toFixed(2)} years - ${interpretation}. ${direction}`
            );
        } else {
            gapInsightText.text("No gap data available for selected year")
        }

        console.log("GapData:", gapData);

        clearGapChart();

        if (gapData.length === 0) {
           // clearGapChart();

            svg3.append("text")
                .attr("class", "no-gap-data")
                .attr("x", width / 2)
                .attr("y", height / 2)
                .attr("text-anchor", "middle")
                .text("No gap data available for this region");
        } else {

            clearGapChart();

            x3.domain(d3.extent(gapData, d => d.year));
            y3.domain([0, d3.max(gapData, d => d.gap)]).nice();

            xAxis3.transition().duration(800).call(d3.axisBottom(x3).ticks(6).tickFormat(d3.format("d")));
            yAxis3.transition().duration(800).call(d3.axisLeft(y3));

            const gapLine = d3.line()
                .x(d => x3(d.year))
                .y(d => y3(d.gap));

            
            const gapPath = svg3.selectAll(".gap-line-path")
            .data([gapData]);

            gapPath.join(
                enter => enter.append("path")
                    .attr("class", "gap-line-path")
                    .attr("fill", "none")
                    .attr("stroke", "#e15759")
                    .attr("stroke-width", 3)
                    .attr("d", gapLine)
                    .attr("opacity", 0)
                    .call(enter => enter.transition().duration(800).attr("opacity", 1)),
               
                update => update
                    .call(update => update.transition().duration(800)
                        .attr("d", gapLine)
                    ),

                exit => exit.remove()

            );

            const dots = svg3.selectAll(".gap-dot")
                .data(gapData, d => d.year);

            dots.join(
                enter => enter.append("circle")
                    .attr("class", "gap-dot")
                    .attr("cx", d => x3(d.year))
                    .attr("cy", d => y3(d.gap))
                    .attr("r", 4)
                    .attr("fill", "#e15759")
                    .on("mouseover", function(event, d) {
                        tooltip.transition().duration(200).style("opacity", 1);

                        tooltip.html(`
                            <strong>Year: ${d.year}</strong><br/>
                            Gap: ${d.gap.toFixed(2)} years
                        `)
                        .style("left", (event.pageX + 10) + "px")
                        .style("top", (event.pageY - 20) + "px");
                    })
                    .on("mouseout", function() {
                        tooltip.transition().duration(200).style("opacity", 0);
                    }),

                update => update
                    .transition()
                    .duration(800)
                    .attr("cx", d => x3(d.year))
                    .attr("cy", d => y3(d.gap)),
                    
            
                exit => exit.remove()
            );

            svg3.selectAll(".year-line").remove();

            selectedYear = +selectedYear;

            const yearPoint = gapData.find(d => d.year === selectedYear);

            if (yearPoint) {
                svg3.append("line")
                    .attr("class", "year-line")
                    .attr("x1", x3(yearPoint.year))
                    .attr("x2", x3(yearPoint.year))
                    .attr("y1", margin.top)
                    .attr("y2", height - margin.bottom)
                    .attr("stroke", "black")
                    .attr("stroke-dasharray", "4,4");

            }

            svg3.selectAll(".trend-annotation").remove();

            const first = gapData[0];
            const last = gapData[gapData.length - 1];

            svg3.append("text")
                .attr("class", "trend-annotation")
                .attr("x", x3(last.year))
                .attr("y", y3(last.gap) - 10)
                .attr("text-anchor", "end")
                .attr("font-size", "12px")
                .style("fill", "#333")
                .text(
                    last.gap > first.gap
                    ? "Gap widening over time"
                    : "Gap narrowing over time"
                );

            
            
        }
      

        

        const line = d3.line()
            .x(d => x3(d.year))
            .y(d => y3(d.gap));

        y1.domain([0, d3.max(lifeData, d => d.value) || 0]).nice();
        y2.domain([0, d3.max(mortalityFormatted, d => d.value) || 0]).nice();

        xAxis1.transition().duration(800).call(d3.axisBottom(x1));
        yAxis1.transition().duration(800).call(d3.axisLeft(y1));

        xAxis2.transition().duration(800).call(d3.axisBottom(x2));
        yAxis2.transition().duration(800).call(d3.axisLeft(y2).ticks(6).tickFormat(d3.format(".0f")));

        const bars1 = g1.selectAll("rect")
            .data(lifeData, d => d.income);

        bars1.join(
            enter => enter.append("rect")
                .attr("x", d => x1(d.income))
                .attr("width", x1.bandwidth())
                .attr("y", y1(0))
                .attr("height", 0)
                .attr("fill", d => d.missing ? "#ccc" : color(d.income))
                .attr("stroke", d => d.missing ? "#666" : "none")
                .attr("stroke-dasharray", d => d.missing ? "4,2" : "none")
                .call(enter => enter.transition()
                    .duration(800)
                    .attr("y", d => y1(d.value))
                    .attr("height", d => height - margin.bottom - y1(d.value))
                )
                .on("mouseover", function(event, d) {
                    tooltip.transition().duration(200).style("opacity", 1);

                    tooltip.html(`
                        <strong>${d.income}</strong><br/>
                        Life Expectancy: ${d.value.toFixed(2)}
                    `)
                    .style("left", (event.pageX + 10) + "px")
                    .style("top", (event.pageY - 20) + "px");
                })
                .on("mousemove", function(event) {
                    tooltip
                        .style("left", (event.pageX + 10) + "px")
                        .style("top", (event.pageY - 20) + "px");
                })
                .on("mouseout", function() {
                    tooltip.transition().duration(200).style("opacity", 0);
                }),

            update => update
                .call(update => update.transition()
                    .duration(800)
                    .attr("x", d => x1(d.income))
                    .attr("y", d => y1(d.value))
                    .attr("height", d => height - margin.bottom - y1(d.value))
                    .attr("fill", d => d.missing ? "#ccc" : color(d.income))
                    .attr("stroke", d => d.missing ? "#666" : "none")
                    .attr("stroke-dasharray", d => d.missing ? "4,2" : "none")
                )
                .on("mouseover", function(event, d) {
                    tooltip.transition().duration(200).style("opacity", 1);

                    tooltip.html(`
                        <strong>${d.income}</strong><br/>
                        Life Expectancy: ${d.value.toFixed(2)}
                    `)
                    .style("left", (event.pageX + 10) + "px")
                    .style("top", (event.pageY - 20) + "px");
                })
                .on("mousemove", function(event) {
                    tooltip
                        .style("left", (event.pageX + 10) + "px")
                        .style("top", (event.pageY - 20) + "px");
                })
                .on("mouseout", function() {
                    tooltip.transition().duration(200).style("opacity", 0);
                }),

            exit => exit
                .call(exit => exit.transition()
                    .duration(500)
                    .attr("y", y1(0))
                    .attr("height", 0)
                    .remove()
                )
        );

        const bars2 = g2.selectAll("rect")
            .data(mortalityFormatted, d => d.income);

        bars2.join(
            enter => enter.append("rect")
                .attr("x", d => x2(d.income))
                .attr("width", x2.bandwidth())
                .attr("y", y2(0))
                .attr("height", 0)
                .attr("fill", d => d.missing ? "#ccc" : color(d.income))
                .attr("stroke", d => d.missing ? "#666" : "none")
                .attr("stroke-dasharray", d => d.missing ? "4,2" : "none")
                .call(enter => enter.transition()
                    .duration(800)
                    .attr("y", d => y2(d.value))
                    .attr("height", d => height - margin.bottom - y2(d.value))
                )
                .on("mouseover", function(event, d) {
                    tooltip.transition().duration(200).style("opacity", 1);

                    tooltip.html(`
                        <strong>${d.income}</strong><br/>
                        Infant Mortality: ${d.value.toFixed(2)}
                    `)
                    .style("left", (event.pageX + 10) + "px")
                    .style("top", (event.pageY - 20) + "px");
                })
                .on("mousemove", function(event) {
                    tooltip
                        .style("left", (event.pageX + 10) + "px")
                        .style("top", (event.pageY - 20) + "px");
                })
                .on("mouseout", function() {
                    tooltip.transition().duration(200).style("opacity", 0);
                }),

            update => update
                .call(update => update.transition()
                    .duration(800)
                    .attr("x", d => x2(d.income))
                    .attr("y", d => y2(d.value))
                    .attr("height", d => height - margin.bottom - y2(d.value))
                    .attr("fill", d => d.missing ? "#ccc" : color(d.income))
                    .attr("stroke", d => d.missing ? "#666" : "none")
                    .attr("stroke-dasharray", d => d.missing ? "4,2" : "none")
                )
                .on("mouseover", function(event, d) {
                    tooltip.transition().duration(200).style("opacity", 1);

                    tooltip.html(`
                        <strong>${d.income}</strong><br/>
                        Infant Mortality: ${d.value.toFixed(2)}
                    `)
                    .style("left", (event.pageX + 10) + "px")
                    .style("top", (event.pageY - 20) + "px");
                })
                .on("mousemove", function(event) {
                    tooltip
                        .style("left", (event.pageX + 10) + "px")
                        .style("top", (event.pageY - 20) + "px");
                })
                .on("mouseout", function() {
                    tooltip.transition().duration(200).style("opacity", 0);
                }),

            exit => exit
                .call(exit => exit.transition()
                    .duration(500)
                    .attr("y", y2(0))
                    .attr("height", 0)
                    .remove()
                )
        );

        svg3.selectAll(".baseline").remove();

        svg3.append("line")
            .attr("class", "baseline")
            .attr("x1", margin.left)
            .attr("x2", width - margin.right)
            .attr("y1", y3(0))
            .attr("y2", y3(0))
            .attr("stroke", "#999")
            .attr("stroke-dasharray", "2,2");

        
        

            



        d3.select("h1").text(`Global Health Dashboard - ${selectedRegion} (${selectedYear})`);
        

    }


    yearSelect.property("value", currentYear);
    updateCharts(currentRegion, currentYear);
    


    
    
});

