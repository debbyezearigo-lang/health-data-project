console.log("FIG 3 LOADED")

Promise.all([
    d3.json("https://raw.githubusercontent.com/debbyezearigo-lang/health-data-project/main/countries.geojson"),
    d3.csv("final_health_dataset_project.csv")
]).then(function([geoData, data]) {

    const width = 900;
    const height = 500;

    const svg = d3.select("#map")
        .append("svg")
        .attr("width", width)
        .attr("height", height);

    const margin = { top: 30, right: 20, bottom: 70, left: 70 };
    const summaryWidth = document.getElementById("summary").clientWidth;
    const summaryHeight = 500;

    const innerWidth = summaryWidth - margin.left - margin.right;
    const innerHeight = summaryHeight - margin.top - margin.bottom;

    const summarySvg = d3.select("#summary")
        .append("svg")
        .attr("width", summaryWidth)
        .attr("height", summaryHeight);

    const g = summarySvg.append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

    const tooltip = d3.select("body")
        .append("div")
        .style("position", "absolute")
        .style("background", "#fff")
        .style("border", "1px solid #ccc")
        .style("padding", "6px")
        .style("opacity", 0);

    data.forEach(d => {
        d.year = +d.year;
        d.life_expect = +d.life_expect;
        d.neonatal_mortality = +d.neonatal_mortality;
        d.under_5_mortality = +d.under_5_mortality;
        d.inci_tuberc = +d.inci_tuberc;
        d.prev_undernourishment = +d.prev_undernourishment;
        d.prev_hiv = +d.prev_hiv;
        d.health_exp = +d.health_exp;
    });

    const years = [...new Set(data.map(d => d.year))].sort();

    const yearSelect = d3.select("#year-select");

    yearSelect.selectAll("option")
        .data(years)
        .enter()
        .append("option")
        .attr("value", d => d)
        .text( d => d);

    const indicators = [
        { value: "life_expect", label: "Life Expectancy" },
        { value: "neonatal_mortality", label: "Neonatal Mortality"  },
        { value: "under_5_mortality", label: "Under 5 Mortality" },
        { value: "inci_tuberc", label: "Tuberculosis Incidence"  },
        { value: "prev_undernourishment", label: "Previous Undernourishment" },
        { value: "prev_hiv", label: "Previous HIV" },
        { value: "health_exp", label: "Health Expenditure"}
    ];

    d3.select("#indicator-select").selectAll("option").remove();

    d3.select("#indicator-select")
        .selectAll("option")
        .data(indicators)
        .enter()
        .append("option")
        .attr("value", d => d.value)
        .text(d => d.label);

    
    let selectedRegion = null;
    let currentYear = years[0];
    let currentIndicator = "life_expect";

    const colorScale = d3.scaleSequential();

    const incomeColor = d3.scaleOrdinal()
        .domain(["High income", "Upper middle income", "Lower middle income", "Low income"])
        .range(["#1b9e77", "#d95f02", "#7570b3", "#e7298a"]);

    const projection = d3.geoNaturalEarth1()
        .fitSize([width, height], geoData);

    const path = d3.geoPath().projection(projection);

    const legendWidth = 200;
    const legendHeight = 15;

    const indicatorLegendSvg = d3.select("#indicator-legend")
        .append("svg")
        .attr("width", 220)
        .attr("height", 80);

    const incomeLegendSvg = d3.select("#income-legend")
        .append("svg")
        .attr("width", 220)
        .attr("height", 120);

    const defs = svg.append("defs");

    const linearGradient = defs.append("linearGradient")
        .attr("id", "legend-gradient")
        .attr("x1", "0%")
        .attr("x2", "100%");


    function getInterpolator(indicator) {
        switch (indicator) {
            case "life_expect":
                return d3.interpolateBlues;
            case "health_exp":
                return d3.interpolateGreens;
            case "neonatal_mortality":
            case "under_5_mortality":
            case "inci_tuberc":
            case "prev_undernourishment":
            case"prev_hiv":
                return d3.interpolateReds;
            default:
                return d3.interpolateGreys;
        }
    }

    const indicatorLabels = {
        life_expect: "Life Expectancy (years)",
        neonatal_mortality: "Neonatal Morality",
        under_5_mortality: "Under 5 Mortality (per 1,000)",
        prev_hiv: "Previous HIV",
        prev_undernourishment: "Prev Undernourishment",
        inci_tuberc: "Tuberculosis Incidence",
        health_exp: "Health Expenditure (% of GDP)"
    }

    


    function update() {

        const filtered = data.filter(d => d.year === currentYear);

        const dataMap = new Map(
            filtered.map(d => [d.country, d])
        );

        const values = filtered
            .map(d => d [currentIndicator])
            .filter(v => v != null && !isNaN(v));

        const extent = d3.extent(values);
        
        const interpolator = getInterpolator(currentIndicator);

        colorScale
            .interpolator(interpolator)
            .domain(extent);

        linearGradient.selectAll("stop")
            .data([
                { offset: "0%", value: extent[0] },
                { offset: "100%", value: extent[1] }
            ])
            .join("stop")
            .attr("offset", d => d.offset)
            .attr("stop-color", d => colorScale(d.value));

        svg.selectAll("path")
            .data(geoData.features)
            .join("path")
            .attr("d", path)
            .attr("fill", d => {
                const val = dataMap.get(d.properties.name)?.[currentIndicator];
                return val ? colorScale(val) : "#ccc";
            })
            .attr("stroke", d => {
                const inc = dataMap.get(d.properties.name)?.["Income group"];
                return incomeColor(inc);
            })
            .attr("stroke-width", 1)
            .on("mouseover", function(event, d) {
                
                const row = dataMap.get(d.properties.name);

                tooltip.style("opacity", 1)
                    .html(`
                        <strong>${d.properties.name}</strong><br>
                        Life Expectancy: ${row?.life_expect ?? "N/A"}<br>
                        Neonatal Mortality: ${row?.neonatal_mortality ?? "N/A"}<br>
                        Under 5 Mortality: ${row?.under_5_mortality ?? "N/A"}<br>
                        Tuberculosis Incidence: ${row?.inci_tuberc ?? "N/A"}<br>
                        Previous Undernourishment: ${row?.prev_undernourishment ?? "N/A"}<br>
                        Previous HIV: ${row?.prev_hiv ?? "N/A"}<br>
                        Health Expenditure: ${row?.health_exp ?? "N/A"}<br>
                        Income: ${row?.["Income group"] ?? "N/A"}    
                    `)
                    .style("left", event.pageX + 10 + "px")
                    .style("top", event.pageY - 20 + "px");
            })
            .on("mouseout", () => tooltip.style("opacity", 0))
            .on("click", function(event, d) {

                const region = dataMap.get(d.properties.name)?.Region;

                if (selectedRegion === region) {
                    selectedRegion = null;
                } else {
                    selectedRegion = region;
                }

                svg.selectAll("path")
                    .attr("opacity", p => {
                        const r = dataMap.get(p.properties.name)?.Region;

                        if (!selectedRegion) return 1;
                        return r === selectedRegion ? 1 : 0.2;
                    });
            });

        const grouped = d3.group(filtered, d => d.Region);

        const boxData = Array.from(grouped, ([region, values]) => {
            const nums = values.map(d => d[currentIndicator])
                .filter(v => v != null && !isNaN(v))
                .sort(d3.ascending);

            return {
                region,
                min: d3.min(nums),
                q1: d3.quantile(nums, 0.25),
                median: d3.quantile(nums, 0.5),
                q3: d3.quantile(nums, 0.75),
                max: d3.max(nums)
            };
        });

        const x = d3.scaleBand()
            .domain(boxData.map(d => d.region))
            .range([0, innerWidth])
            .padding(0.3);

        const y = d3.scaleLinear()
            .domain([
                d3.min(boxData, d => d.min),
                d3.max(boxData, d => d.max)
            ])
            .nice()
            .range([innerHeight, 0]);

        g.selectAll("*").remove();

        summarySvg.selectAll(".chart-title").remove();
        summarySvg.selectAll(".axis-label").remove();

        g.append("g")
            .attr("transform", `translate(0,${innerHeight})`)
            .call(d3.axisBottom(x))
            .selectAll("text")
            .attr("transform", "rotate(-40)")
            .style("text-anchor", "end");

        g.append("g")
            .call(d3.axisLeft(y));

        g.selectAll(".box")
            .data(boxData)
            .enter()
            .append("rect")
            .attr("class", "box")
            .attr("x", d => x(d.region))
            .attr("y", d => y(d.q3))
            .attr("height", d => y(d.q1) - y(d.q3))
            .attr("width", x.bandwidth())
            .attr("fill", "#4e79a7")
            .on("mouseover", function(event, d) {

                tooltip.style("opacity", 1)
                    .html(`
                        <strong>${d.region}</strong><br>
                        Min: ${d.min.toFixed(2)}<br>
                        Q1: ${d.q1.toFixed(2)}<br>
                        Median: ${d.median.toFixed(2)}<br>
                        Q3: ${d.q3.toFixed(2)}<br>
                        Max: ${d.max.toFixed(2)}    
                    `)
                    .style("left", event.pageX + 10 + "px")
                    .style("top", event.pageY - 20 + "px");
            })
            .on("mousemove", function(event) {
                tooltip
                    .style("left", event.pageX + 10 + "px")
                    .style("top", event.pageY - 20 + "px");
            })
            .on("mouseout", () => tooltip.style("opacity", 0));

        g.selectAll(".median")
            .data(boxData)
            .enter()
            .append("line")
            .attr("x1", d => x(d.region))
            .attr("x2", d => x(d.region) + x.bandwidth())
            .attr("y1", d => y(d.median))
            .attr("y2", d => y(d.median))
            .attr("stroke", "black");

        g.selectAll(".whisker")
            .data(boxData)
            .enter()
            .append("line")
            .attr("x1", d => x(d.region) + x.bandwidth() / 2)
            .attr("x2", d => x(d.region) + x.bandwidth() / 2)
            .attr("y1", d => y(d.min))
            .attr("y2", d => y(d.max))
            .attr("stroke", "black");

        summarySvg.append("text")
            .attr("class", "axis-label")
            .attr("x", summaryWidth / 2)
            .attr("y", summaryHeight - 10)
            .attr("text-anchor", "middle")
            .text("Region");

        summarySvg.append("text")
            .attr("class", "axis-label")
            .attr("transform", "rotate(-90)")
            .attr("x", -summaryHeight / 2)
            .attr("y", 15)
            .attr("text-anchor", "middle")
            .text(`Distribution of ${currentIndicator}`);

        summarySvg.append("text")
            .attr("class", "chart-title")
            .attr("x", summaryWidth / 2)
            .attr("y", 15)
            .attr("text-anchor", "middle")
            .style("font-weight", "bold")
            .text(`Regional Distribution of ${currentIndicator}`);

       
        

        indicatorLegendSvg.selectAll("*").remove();

        

        indicatorLegendSvg.append("text")
            .attr("x", 0)
            .attr("y", 15)
            .style("font-weight", "bold")
            .text(indicatorLabels[currentIndicator]);

        indicatorLegendSvg.append("rect")
            .attr("x", 0)
            .attr("y", 20)
            .attr("width", legendWidth)
            .attr("height", legendHeight)
            .style("fill", "url(#legend-gradient)");

        
        indicatorLegendSvg.append("text")
            .attr("x", 0)
            .attr("y", 50)
            .text(extent[0].toFixed(1));

        indicatorLegendSvg.append("text")
            .attr("x", legendWidth)
            .attr("y", 50)
            .attr("text-anchor", "end")
            .text(extent[1].toFixed(1));


    }

    incomeLegendSvg.selectAll("*").remove();


    const groups = incomeColor.domain();

    incomeLegendSvg.append("text")
        .attr("x", 0)
        .attr("y", 15)
        .style("font-weight", "bold")
        .text("Income Group");

    groups.forEach((gName, i) => {
        const row = incomeLegendSvg.append("g")
            .attr("transform", `translate(0, ${30 + i * 20})`);

        row.append("rect")
            .attr("width", 12)
            .attr("height", 12)
            .attr("fill", incomeColor(gName));

        row.append("text")
            .attr("x", 20)
            .attr("y", 10)
            .text(gName);
    });

    d3.select("#indicator-select").on("change", function() {
        currentIndicator = this.value;
        update();
    });

    yearSelect.on("change", function() {
        currentYear = +this.value;
        update();
    });

    update();

});